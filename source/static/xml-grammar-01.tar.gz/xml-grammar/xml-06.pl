grammar XML {
    token TOP   { ^ <xml> $ };
    token xml   { <plain> [ <tag> <plain> ]*  };
    token plain { <-[<>&]>*  };
    token tag   {
        '<' (\w+) <attribute>* '>'
        <xml>
        '</' $0   '>'
    };
    token attribute {
        \w+ '="' <-["<>]>* \"
    }
};

my @tests = (
    [1, 'abc'                       ],
    [1, '<a></a>'                   ],
    [1, '..<ab>foo</ab>dd'          ],
    [1, '<a><b>c</b></a>'           ],
    [1, '<a href="foo"><b>c</b></a>'],
    [1, '<a empty="" ><b>c</b></a>' ],
    [1, '<a><b>c</b><c></c></a>'    ],
    [0, '<'                         ],
    [0, '<a>b</b>'                  ],
    [0, '<a>b</a'                   ],
    [0, '<a>b</a href="">'          ],
    [1, '<a/>'                      ],
    [1, '<a />'                     ],
);


my $count = 1;
for @tests -> $t {
    my $s = $t[1];
    my $M := $s ~~ XML::TOP;
    if !($M  xor $t[0]) {
        say "ok $count - '$s'";
    } else {
        say "not ok $count - '$s'";
    }
    $count++;
}

# vim: ft=perl6
