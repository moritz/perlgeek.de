#ifndef _MYHEAP_HPP_
#define _MYHEAP_HPP_

class myheap {
	public:
		// Erstelle einen neuen Heap mit mix. size Elementen
		myheap(int size);
		// Erstelle einen Heap aus dem Array a[] mit size Elementen
		myheap(int a[], int size);

		~myheap();

		// Lege item auf dem Heap ab
		void push(int item);

		// entferne den Wurzelknoten und liefere das Element
		// zur&uuml;ck
		int pop(void);

	protected:
		int *data;
		int pointer;

		void reheap_up(int start);
		void reheap_up_modified(int pointer);
		void reheap_down(int pointer);

		void reheap_all();

		void check_heap_condition(void);

};

#endif
