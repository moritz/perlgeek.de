#include "myheap.hpp"
#include <stdlib.h>
#include <stdio.h>

myheap::myheap(int size){
	data = new int[size + 2];
	pointer = 0;
}

myheap::myheap(int *a, int size){
	data = new int[size + 2];
	for (int i = 0; i < size; i++){
		data[i+1] = a[i];
	}
	pointer = size;
	reheap_all();

}

myheap::~myheap(){
	delete[] data;
}


void myheap::push(int item){
	pointer ++;
	data[pointer] = item;
	reheap_up(pointer);
}

void myheap::reheap_up(int start){
	int p =start;
	int new_p = p / 2;
	while (p > 1 && 
			data[new_p] > data[p]){
		/* swap the two elements */
		int tmp = data[new_p];
		data[new_p] = data[p];
		data[p] = tmp;
		p = p / 2;
		new_p = new_p / 2;
	}
}

void myheap::reheap_all(){
	int p;
	for (p = 1; p <= pointer; p++){
		reheap_up(p);
	}
}


void myheap::reheap_down(int pointer){
	int new_p;
	if (2 * pointer > this->pointer){
		return;
	}
	if (2 * pointer + 1 <= this->pointer && data[2*pointer+1] < data[2*pointer]){
		new_p = 2 * pointer + 1;
	} else {
		new_p = 2 * pointer;
	}
	if (data[pointer] > data[new_p]){
		int tmp = data[pointer];
		data[pointer] = data[new_p];
		data[new_p] = tmp;
		reheap_down(new_p);
	}
}

int myheap::pop(void){
	int res = data[1];
	data[1] = data[pointer];
	pointer--;
	reheap_down(1);
	return res;

}

void myheap::check_heap_condition(void){
	int i; 
	for (i = 2; i <= pointer; i++){
		if (data[i/2] > data[i]){
			printf("\nError at index %d, %d\n", i, i/2);
			exit(1);
		}

	}

}

