#include <iostream>
#include "myheap.hpp"

using std::cout;

int main(int argc, char** argv){
	int a[8] = {1, 6, 8, 3, 2, 7, 3, 4};
	myheap h1(a, 8); 
	for (int i = 0; i < 8; i++){
		cout << h1.pop() << "\n";
	}


	return 0;
}
