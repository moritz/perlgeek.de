$_ = "1" x shift;
if (m/^1?$|^(11+?)\1+$/) {
    print "No prime\n";
} else {
    print "A prime\n";
}
