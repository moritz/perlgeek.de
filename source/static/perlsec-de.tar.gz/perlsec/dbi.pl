use strict; use warnings;
use DBI;
my $handle = DBI->connect(...);
my $statement = $handle->prepare(
    'SELECT * FROM users WHERE password = ?'
);
$statement->execute($ARGV[0]);
# oder
$handle->do('DELETE FROM users WHERE id = ?', $id);
