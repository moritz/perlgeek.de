#!/usr/bin/perl
use strict;
use warnings;
use Benchmark qw(timethis);

my $str = 'a' x shift;
timethis(1, sub {
        $str =~ m/([abc]*[ab]*){2,12109}\d/;

});
